package com.TKAGopal.Project.Session;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
